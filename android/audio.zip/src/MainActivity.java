package {{PACKAGENAME}};

import java.io.IOException;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        //T("Start");
        try {
            AssetFileDescriptor descriptor = getAssets()
                .openFd("{{AUDIONAME}}");

            MediaPlayer player = new MediaPlayer();

            player.setDataSource(descriptor
                .getFileDescriptor());
            player.prepare();
            player.start();
            //T("Done");
            //this.finish();
        } catch (IOException e) {
            T(e.toString());
        } finally {
            this.finish();
        }
    }

    private void T(CharSequence text) {
        Toast.makeText(getApplicationContext(), text,
            Toast.LENGTH_SHORT).show();
    }
}